<!doctype html>
<html lang="en">
<head>
<title>Success</title>
<?php                 
include "../control/header2.php";

?>


<script>

    alert("Staff Added")
</script>
</head>
<body>

<
<?php
header("refresh:0;url=../control/AdminPanel.php");
include "../view/footer.php";                
?>
</body>
</html>
