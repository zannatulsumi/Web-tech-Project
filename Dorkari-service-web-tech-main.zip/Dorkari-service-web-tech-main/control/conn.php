<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dorkari";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


 ?>