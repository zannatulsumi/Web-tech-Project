<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offer Job</title>
<?php
include "header.php";                  
?>
</head>
<body>

<h1 align="center">Explore Available Jobs</h1>

    <h4>Electrician</h4>
    <span>Job Details: TV, AC, Fridge, Ovan, Heater Repiring</span> <br>
    <span>Dhaka, Bangladesh</span> <br>
    <span>Full Time || Part Time ৳12345 - ৳26789</span> <br>
    <a href="../view/comingsoon.php">Apply Now</a>

    <h4>Painter</h4>
    <span>Job Details: Painting wall, Furnitures</span> <br>
    <span>Dhaka, Bangladesh</span> <br>
    <span>Full Time || Part Time ৳12345 - ৳26789</span> <br>
    <a href="../view/comingsoon.php">Apply Now</a>

    <h4>Mechanic</h4>
    <span>Job Details: Car, Engine - Parts Repire, Wash</span> <br>
    <span>Dhaka, Bangladesh</span> <br>
    <span>Full Time || Part Time ৳12345 - ৳26789</span> <br>
    <a href="../view/comingsoon.php">Apply Now</a>

    <h4>Janitor</h4>
    <span>Job Details: Cleaning House, Pest Control, Wash, clean and iron dresses </span> <br>
    <span>Dhaka, Bangladesh</span> <br>
    <span>Full Time || Part Time ৳12345 - ৳26789</span> <br>
    <a href="../view/comingsoon.php">Apply Now</a>

    <h4>Driver</h4>
    <span>Job Details: Driving Car </span> <br>
    <span>Dhaka, Bangladesh</span> <br>
    <span>Full Time || Part Time ৳12345 - ৳26789</span> <br>
    <a href="../view/comingsoon.php">Apply Now</a>

    <h4>Delivery Boy</h4>
    <span>Job Details: Deliver Products </span> <br>
    <span>Dhaka, Bangladesh</span> <br>
    <span>Full Time || Part Time ৳12345 - ৳26789</span> <br>
    <a href="../view/comingsoon.php">Apply Now</a>

  
        <center><h1>We Help To Get The Best Job</h1></center>






<?php
include "footer.php";                
?>
</body>
</html>