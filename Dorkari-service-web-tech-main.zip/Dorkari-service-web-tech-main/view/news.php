<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>temp</title>
<?php
include "header.php";                  
?>
</head>
<body>
    <center> <embed type="text/html" src="https://www.thedailystar.net/"  width="1500" height="550">
    <form action="../view/index.php" method="get">
  <button type="submit" class="w3-button w3-red w3-padding-small w3-large w3-center">Homepage</button>
</form> </center>


<?php
include "footer.php";                
?>
</body>
</html>