<!DOCTYPE html>
<html lang="en">
<head>

</head   

<body>
    
<footer class="w3-container w3-padding-64 w3-center w3-opacity"> 
 <div class="w3-container w3-black w3-center w3-opacity w3-padding-64">   

<h4>Find Us</h4>
	<h5>123 Street, Dhaka, bangladesh</h5>
	<h5>01781770073</h5>
	<h5>info@dorkari.com</h5>
    <a href="../view/index.php">Home</a>
  <a href="../view/Services.php">Our Services</a>
  <a href="../view/us.php">Contact US</a>
  <a href="../view/PP.php">Privacy Policy</a>
  <a href="../view/tnc.php">Terms & Condition</a>
  <a href="../view/stafflogin.php">Staff Login</a>
  <a href="../view/adminlogin.php">Admin Login</a>
  <center><h3 style="color: white;">Copyright © 2022 Dorkari Platform Limited | All Rights Reserved.</h1></center>
</div>
 </footer>
</body>
</html>